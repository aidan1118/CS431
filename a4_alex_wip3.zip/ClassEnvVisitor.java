package semant;

import ast.*;
import visitor.*;
import util.*;
import java.util.*;

/** Visitor class for typechecking the AST */
public class ClassEnvVisitor extends Visitor {
    private static HashSet<String> reservedNames =
        new HashSet<String>(Arrays.asList("this", "super", "null"));
    private static HashSet<String> allowedPrimitives =
        new HashSet<String>(Arrays.asList("boolean", "int"));

    private ErrorHandler errorHandler;
    private Hashtable<String, ClassTreeNode> classMap;
    private ClassTreeNode curClass;
    
    public ClassEnvVisitor(Hashtable<String, ClassTreeNode> classMap,
        ErrorHandler errorHandler) {
        this.classMap = classMap;
        this.errorHandler = errorHandler;
    }

    /** Build symbol table for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(Class_ node) {
        curClass = classMap.get(node.getName());
        MemberList memberList = node.getMemberList();
        Iterator<ASTNode> iter = memberList.getIterator();
        
        curClass.getVarSymbolTable().enterScope();
        curClass.getMethodSymbolTable().enterScope();
        while (iter.hasNext()) {
            iter.next().accept(this);
        }

        return null;
    }
    
    /** Build symbol table for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(Field node) {
        SymbolTable varSymbolTable = curClass.getVarSymbolTable();
        String type = node.getType();
        String check = type;
        String name = node.getName();

        if (check.endsWith("[]")) {
            check = check.substring(0, check.length() - 2);
        }

        if (reservedNames.contains(name)) {
            errorHandler.register(errorHandler.SEMANT_ERROR,
                "Field name is reserved");
            return null;
        }

        int curScope = varSymbolTable.getCurrScopeLevel();
        if (varSymbolTable.lookup(name) != null &&
            varSymbolTable.getScopeLevel(name) == curScope) {
            errorHandler.register(errorHandler.SEMANT_ERROR,
                "Multiply declared field");
            return null;
        }

        if (!allowedPrimitives.contains(check) && !classMap.containsKey(check)) {
            errorHandler.register(errorHandler.SEMANT_ERROR,
                "Invalid field type");
            return null;
        }

        varSymbolTable.add(name, type);
        varSymbolTable.add("this." + name, type);
        return null;
    }
    
    /** Build symbol table for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(Method node) {
        SymbolTable methodSymbolTable = curClass.getMethodSymbolTable();
        String baseType = node.getReturnType();
        String type = baseType;
        String name = node.getName();

        if (type.endsWith("[]")) {
            type = type.substring(0, type.length() - 2);
        }

        if (!type.equals("void") && !allowedPrimitives.contains(type) &&
            !classMap.containsKey(type)) {
            errorHandler.register(errorHandler.SEMANT_ERROR,
                "Invalid return type");
            return null;
        }

        if (reservedNames.contains(name)) {
            errorHandler.register(errorHandler.SEMANT_ERROR,
                "Method name is reserved");
            return null;
        }

        int curScope = methodSymbolTable.getCurrScopeLevel();
        if (methodSymbolTable.lookup(name) != null &&
            methodSymbolTable.getScopeLevel(name) == curScope) {
            errorHandler.register(errorHandler.SEMANT_ERROR,
                "Multiply declared method");
            return null;
        }

        ClassTreeNode parent = curClass.getParent();
        Method inherited = null;

        if (parent != null) {
            Object temp = methodSymbolTable.lookup(name);
            if (temp != null && temp instanceof Method) {
                inherited = (Method)temp;
            }
        }

        if (inherited != null) {
            if (!inherited.getReturnType().equals(baseType)) {
                errorHandler.register(errorHandler.SEMANT_ERROR,
                    "Method return type does not match inherited");
                return null;
            }

            FormalList curList = node.getFormalList();
            FormalList inheritedList = inherited.getFormalList();

            if (curList.getSize() != inheritedList.getSize()) {
                errorHandler.register(errorHandler.SEMANT_ERROR,
                    "Method formal count does not match inherited");
                return null;
            }

            Iterator<ASTNode> curIter = curList.getIterator();
            Iterator<ASTNode> inheritedIterator = inheritedList.getIterator();

            while (curIter.hasNext() && inheritedIterator.hasNext()) {
                Formal curFormal = (Formal)curIter.next();
                Formal inheritedFormal = (Formal)inheritedIterator.next();

                if (!curFormal.getType().equals(inheritedFormal.getType())) {
                    errorHandler.register(errorHandler.SEMANT_ERROR,
                        "Method formal type does not match inherited");
                    return null;
                }
            }
        }

        methodSymbolTable.add(name, node);
        return null;
    }
}