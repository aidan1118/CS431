package codegenjvm;

import java.io.*;
import java.util.*;
import ast.*;
import util.ClassTreeNode;
import util.SymbolTable;
import visitor.Visitor;

public class CodeGenVisitor extends Visitor {
    private Hashtable<String, ClassTreeNode> classMap;
    private OutputStringWriter writer;
    private PrintStream outStream;
    private Class_ curClass;

    private int stack = 0;
    private int maxStack = 0;
    private int desiredStack = 0;
    private LocalList locals = new LocalList();
    private LabelList labels = new LabelList();

    private boolean storeIntoVar = false;

    public CodeGenVisitor(Hashtable<String, ClassTreeNode> classMap) {
        this.classMap = classMap;

        writer = new OutputStringWriter();
    }

    public void setOutStream(PrintStream outStream) {
        this.outStream = outStream;
        writer = new OutputStringWriter();
    }

    private void setStack(int stack) {
        this.stack = stack;
        maxStack = stack;
    }

    private void incrStack() {
        stack++;
        maxStack = Math.max(maxStack, stack);
    }

    private void decrStack() {
        stack--;
    }

    private String getClassWithField(String initialClass, String field) {
        ClassTreeNode node = classMap.get(initialClass);
        SymbolTable symbolTable = node.getVarSymbolTable();
        while (symbolTable.peek(field) == null) {
            node = node.getParent();
            symbolTable = node.getVarSymbolTable();
        }

        return node.getName();
    }

    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(Class_ node) {
        curClass = node;
        
        String parent = TypeHelper.getBase(node.getParent());
        writer.println(".source " + node.getFilename());
        writer.println(".class public " + node.getName());
        writer.println(".super " + parent);
        writer.println(".implements java/lang/Cloneable");
        writer.println();

        ArrayList<Field> fields = new ArrayList<>();
        ArrayList<Method> methods = new ArrayList<>();
        Iterator<ASTNode> iter = node.getMemberList().getIterator();
        
        while (iter.hasNext()) {
            ASTNode member = iter.next();
            
            if (member instanceof Field) {
                fields.add((Field)member);
            }
            else if (member instanceof Method) {
                methods.add((Method)member);
            }
        }

        ArrayList<String> constructor = new ArrayList<>();
        setStack(2);
        String name = TypeHelper.getDescriptor(node.getName());
        locals.reset("this", name);
        labels.clear();

        for (Field field : fields) {
            writer.print(".field ");
            field.accept(this);

            constructor.add(writer.getString());
            writer.exitScope();
        }

        writer.println();
        writer.println(".method public <init>()V");
        
        writer.incrIndent(2);
        writer.println(".limit stack " + maxStack);
        writer.println(".limit locals " + locals.size());
        
        writer.decrIndent();
        writer.println(Bytecodes.aload(0));
        writer.println("invokespecial " + parent + "/<init>()V");
        
        for (String init : constructor) {
            writer.print(init);
        }
        
        writer.println("return");
        writer.decrIndent();
        writer.println(".end method");
        writer.println();

        for (Method method : methods) {
            method.accept(this);
        }

        System.out.println(writer.getString());
        outStream.println(writer.getString());
        outStream.close();
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(Field node) {
        String type = TypeHelper.getDescriptor(node.getType());
        writer.println("protected " + node.getName() + " " + type);

        writer.enterScope();
        if (node.getInit() != null) {
            node.getInit().accept(this);
        }
        else {
            if (TypeHelper.isPrimitive(node.getType())) {
                writer.println(Bytecodes.ldc(0));
            }
            else {
                writer.println(Bytecodes.aload(-1));
            }

            incrStack();
        }
        
        writer.println(Bytecodes.aload(0));
        String className = TypeHelper.getBase(curClass.getName());
        writer.println("putfield " + className + "/" + node.getName() +
            " " + type);
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(Method node) {
        setStack(0);
        String className = TypeHelper.getDescriptor(curClass.getName());
        locals.reset("this", className);
        labels.clear();

        writer.print(".method public ");
        writer.enterScope();
        writer.print(node.getName() + "(");
        boolean returned = false;

        Iterator<ASTNode> formals = node.getFormalList().getIterator();
        while (formals.hasNext()) {
            formals.next().accept(this);
        }

        writer.print(")" + TypeHelper.getDescriptor(node.getReturnType()));
        String signature = writer.getString();
        
        writer.exitScope();
        writer.finishln(signature);
        writer.enterScope();

        Iterator<ASTNode> stmts = node.getStmtList().getIterator();
        while (stmts.hasNext()) {
            ASTNode next = stmts.next();
            next.accept(this);
            if (!stmts.hasNext() && next instanceof ReturnStmt) {
                returned = true;
            }
        }

        if (node.getReturnType().equals("void") && !returned) {
            writer.println("return");
        }

        String inner = writer.getProcessed(labels);
        writer.exitScope();

        writer.println(".throws java/lang/CloneNotSupportedException");
        writer.incrIndent(2);
        writer.println(".limit stack " + maxStack);
        writer.println(".limit locals " + locals.size());
        writer.decrIndent(2);

        writer.println(inner);
        writer.println(".end method");
        writer.println();
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(Formal node) {
        String descriptor = TypeHelper.getDescriptor(node.getType());
        locals.declare(node.getName(), descriptor);
        writer.print(descriptor);
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(DeclStmt node) {
        String name = node.getName();
        String type = TypeHelper.getDescriptor(node.getType());
        locals.declare(name, type);
        int index = locals.getIndex(name);

        writer.println("; local var declaration: " + name + " " + index);

        if (node.getInit() != null) {
            node.getInit().accept(this);
            
            if (TypeHelper.isPrimitive(node.getType())) {
                writer.println(Bytecodes.istore(index));
                decrStack();
            }
            else {
                writer.println(Bytecodes.astore(index));
                decrStack();
            }
        }

        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(IfStmt node) {
        int height = stack;
        desiredStack = height;
        String thenLbl = labels.add();
        labels.setThen(thenLbl);
        String elseLbl = labels.add();
        labels.setElse(elseLbl);
        String exitLbl = labels.add();
        
        writer.println("; if statement: condition");
        node.getPredExpr().accept(this);

        writer.println("; if statement: then block");
        writer.printlbl(thenLbl, labels);
        node.getThenStmt().accept(this);
        while (stack > height) {
            writer.println("pop");
            decrStack();
        }
        writer.println("goto " + exitLbl);

        writer.println("; if statement: else block");
        writer.printlbl(elseLbl, labels);
        node.getElseStmt().accept(this);
        while (stack > height) {
            writer.println("pop");
            decrStack();
        }
        writer.printlbl(exitLbl, labels);
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(WhileStmt node) {
        int height = stack;
        desiredStack = height;
        String condLbl = labels.add();
        writer.printlbl(condLbl, labels);
        String thenLbl = labels.add();
        labels.setThen(thenLbl);
        String elseLbl = labels.add();
        labels.setLoopElse(elseLbl);

        writer.println("; while loop condition");
        node.getPredExpr().accept(this);
        while (stack > height) {
            writer.println("pop");
            decrStack();
        }

        writer.println("; while loop body");
        writer.printlbl(thenLbl, labels);

        node.getBodyStmt().accept(this);
        while (stack > height) {
            writer.println("pop");
            decrStack();
        }

        writer.println("; bottom of while loop");
        writer.println("goto " + condLbl);
        writer.printlbl(elseLbl, labels);
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(ForStmt node) {
        int height = stack;
        desiredStack = height;
        if (node.getInitExpr() != null) {
            writer.println("; for loop init");
            node.getInitExpr().accept(this);
        }

        String condLbl = labels.add();
        writer.printlbl(condLbl, labels);
        String thenLbl = labels.add();
        labels.setThen(thenLbl);
        String elseLbl = labels.add();
        labels.setLoopElse(elseLbl);

        if (node.getPredExpr() != null) {
            writer.println("; for loop condition");
            node.getPredExpr().accept(this);
        }
        
        writer.printlbl(thenLbl, labels);

        writer.println("; for loop body");
        node.getBodyStmt().accept(this);
        if (node.getUpdateExpr() != null) {
            writer.println("; for loop update");
            node.getUpdateExpr().accept(this);
        }

        while (stack > height) {
            writer.println("pop");
            decrStack();
        }

        writer.println("; bottom of for loop");
        writer.println("goto " + condLbl);
        writer.printlbl(elseLbl, labels);
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(BlockStmt node) {
        locals.enterScope();
        Iterator<ASTNode> iter = node.getStmtList().getIterator();
        while (iter.hasNext()) {
            iter.next().accept(this);
        }

        locals.exitScope();
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(BreakStmt node) {
        while (stack > desiredStack) {
            writer.println("pop");
            decrStack();
        }

        String elseLbl = labels.getLoopElse();
        writer.println("goto " + elseLbl);
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(ReturnStmt node) {
        Expr expr = node.getExpr();

        if (expr != null) {
            expr.accept(this);
            String type = expr.getExprType();
            
            if (TypeHelper.isPrimitive(type)) {
                writer.println("ireturn");
            }
            else if (TypeHelper.isVoid(type)) {
                writer.println("return");
            }
            else {
                writer.println("areturn");
            }
            
            decrStack();
        }
        
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(DispatchExpr node) {
        int height = stack;
        Expr ref = node.getRefExpr();
        String source = curClass.getName();
        boolean isSuper = false;

        if (ref != null) {
            if (ref instanceof VarExpr) {
                VarExpr expr = (VarExpr)ref;
                if (expr.getName().equals("super")) {
                    writer.println("; dispatch: " + curClass.getParent() +
                        "." + node.getMethodName());
                }
                else {
                    writer.println("; dispatch: " + expr.getName() +
                        "." + node.getMethodName());
                }
            }

            ref.accept(this);

            if (ref instanceof VarExpr) {
                VarExpr expr = (VarExpr)ref;

                if (expr.getName().equals("super")) {
                    source = curClass.getParent();
                    isSuper = true;
                }
                else if (!expr.getName().equals("this")) {
                    source = expr.getExprType();
                }
            }
            else {
                source = ref.getExprType();
            }

            if (TypeHelper.isArrayBase(ref.getExprType())) {
                source = "Object";

                while (stack > height) {
                    decrStack();
                }
            }
        }
        else {
            writer.println("; dispatch: " + source +
                "." + node.getMethodName());
            writer.println(Bytecodes.aload(0));
            incrStack();
        }

        String actualDescriptor = "";
        Iterator<ASTNode> iter = node.getActualList().getIterator();
        while (iter.hasNext()) {
            Expr actual = (Expr)iter.next();
            actual.accept(this);
            actualDescriptor += TypeHelper.getDescriptor(actual.getExprType());
        }

        String retType;

        if (isSuper) {
            ClassTreeNode parent = classMap.get(curClass.getParent());
            SymbolTable symbolTable = parent.getMethodSymbolTable();
            Method method = (Method)symbolTable.lookup(node.getMethodName());
            retType = method.getReturnType();

            writer.println("invokespecial " + TypeHelper.getBase(source) +
                "/" + node.getMethodName() + "(" + actualDescriptor + ")" +
                TypeHelper.getDescriptor(retType));
        }
        else {
            ClassTreeNode parent = classMap.get(source);
            SymbolTable symbolTable = parent.getMethodSymbolTable();
            Method method = (Method)symbolTable.lookup(node.getMethodName());
            retType = method.getReturnType();

            writer.println("invokevirtual " + TypeHelper.getBase(source) +
                "/" + node.getMethodName() + "(" + actualDescriptor + ")" +
                TypeHelper.getDescriptor(retType));
        }

        while (stack > height) {
            decrStack();
        }

        if (!TypeHelper.isVoid(retType)) {
            incrStack();
        }

        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(CastExpr node) {
        node.getExpr().accept(this);
        String type = TypeHelper.getBase(node.getType());
        writer.println("checkcast " + type);
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(InstanceofExpr node) {
        node.getExpr().accept(this);
        String type = TypeHelper.getBase(node.getExprType());
        writer.println("instanceof " + type);
        decrStack();
        incrStack();
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(NewExpr node) {
        String type = TypeHelper.getBase(node.getType());
        writer.println("new " + type);
        writer.println("dup");
        writer.println("invokespecial " + type + "/<init>()V");

        incrStack();
        incrStack();
        decrStack();
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(NewArrayExpr node) {
        String type = node.getType();
        node.getSize().accept(this);

        if (TypeHelper.isPrimitive(type)) {
            writer.println("newarray " + type);
        }
        else {
            writer.println("anewarray " + TypeHelper.getBase(type));
        }

        decrStack();
        incrStack();
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(AssignExpr node) {
        String ref = node.getRefName();
        String name = node.getName();
        writer.println("; var assign: " + name);
        
        if (ref != null && ref.equals("this") || locals.getIndex(name) < 0) {
            writer.println(Bytecodes.aload(0));
            incrStack();

            node.getExpr().accept(this);
            String parent = getClassWithField(curClass.getName(), name);
            writer.println("putfield " + parent + "/" +  name +
                " " + TypeHelper.getDescriptor(node.getExprType()));

            decrStack();
            decrStack();
        }
        else {
            int index = locals.getIndex(name);

            if (TypeHelper.isPrimitive(node.getExprType())) {
                writer.println(Bytecodes.iload(index));
                incrStack();

                node.getExpr().accept(this);
                writer.println(Bytecodes.istore(index));
            }
            else {
                writer.println(Bytecodes.aload(index));
                incrStack();
    
                node.getExpr().accept(this);
                writer.println(Bytecodes.astore(index));
            }

            decrStack();
        }

        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(ArrayAssignExpr node) {
        String ref = node.getRefName();
        String name = node.getName();
        writer.println("; array assign: " + name);
        
        if (ref != null && ref.equals("this") || locals.getIndex(name) < 0) {
            writer.println(Bytecodes.aload(0));
            incrStack();

            String parent = getClassWithField(curClass.getName(), name);
            writer.println("getfield " + parent + "/" +  name +
                " " + TypeHelper.getDescriptor(node.getExprType() + "[]"));

            decrStack();
            incrStack();
        }
        else {
            int index = locals.getIndex(name);
            writer.println(Bytecodes.aload(index));
            incrStack();
        }
            
        node.getIndex().accept(this);
        node.getExpr().accept(this);

        String type = TypeHelper.getNonArrayType(node.getExprType());
        if (TypeHelper.isPrimitive(type)) {
            writer.println("iastore");
        }
        else {
            writer.println("aastore");
        }

        decrStack();
        decrStack();
        decrStack();
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(UnaryDecrExpr node) {
        node.getExpr().accept(this);
        writer.println(Bytecodes.ldc(-1));
        writer.println("iadd");

        storeIntoVar = true;
        writer.println("dup");
        node.getExpr().accept(this);
        storeIntoVar = false;
        
        incrStack();
        decrStack();
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(UnaryIncrExpr node) {
        node.getExpr().accept(this);
        writer.println(Bytecodes.ldc(1));
        writer.println("iadd");

        storeIntoVar = true;
        writer.println("dup");
        node.getExpr().accept(this);
        storeIntoVar = false;

        incrStack();
        decrStack();
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(UnaryNegExpr node) {
        node.getExpr().accept(this);
        writer.println("ineg");
        decrStack();
        incrStack();
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(UnaryNotExpr node) {
        node.getExpr().accept(this);
        writer.println("ineg");
        writer.println(Bytecodes.ldc(1));
        writer.println("iadd");
        incrStack();
        decrStack();
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(BinaryArithDivideExpr node) {
        node.getLeftExpr().accept(this);
        node.getRightExpr().accept(this);
        writer.println("idiv");
        decrStack();
        decrStack();
        incrStack();
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(BinaryArithMinusExpr node) {
        node.getLeftExpr().accept(this);
        node.getRightExpr().accept(this);
        writer.println("isub");
        decrStack();
        decrStack();
        incrStack();
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(BinaryArithModulusExpr node) {
        node.getLeftExpr().accept(this);
        node.getRightExpr().accept(this);
        writer.println("irem");
        decrStack();
        decrStack();
        incrStack();
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(BinaryArithPlusExpr node) {
        node.getLeftExpr().accept(this);
        node.getRightExpr().accept(this);
        writer.println("iadd");
        decrStack();
        decrStack();
        incrStack();
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(BinaryArithTimesExpr node) {
        node.getLeftExpr().accept(this);
        node.getRightExpr().accept(this);
        writer.println("imul");
        decrStack();
        decrStack();
        incrStack();
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(BinaryCompEqExpr node) {
        String left = node.getLeftExpr().getExprType();
        node.getLeftExpr().accept(this);
        String right = node.getRightExpr().getExprType();
        node.getRightExpr().accept(this);

        if (TypeHelper.isPrimitive(left) && TypeHelper.isPrimitive(right)) {
            writer.println("if_icmpne " + labels.getElse());
        }
        else {
            writer.println("if_acmpne " + labels.getElse());
        }
        
        decrStack();
        decrStack();
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(BinaryCompGeqExpr node) {
        node.getLeftExpr().accept(this);
        node.getRightExpr().accept(this);
        writer.println("if_icmplt " + labels.getElse());
        decrStack();
        decrStack();
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(BinaryCompGtExpr node) {
        node.getLeftExpr().accept(this);
        node.getRightExpr().accept(this);
        writer.println("if_icmple " + labels.getElse());
        decrStack();
        decrStack();
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(BinaryCompLeqExpr node) {
        node.getLeftExpr().accept(this);
        node.getRightExpr().accept(this);
        writer.println("if_icmpgt " + labels.getElse());
        decrStack();
        decrStack();
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(BinaryCompLtExpr node) {
        node.getLeftExpr().accept(this);
        node.getRightExpr().accept(this);
        writer.println("if_icmpge " + labels.getElse());
        decrStack();
        decrStack();
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(BinaryCompNeExpr node) {
        String left = node.getLeftExpr().getExprType();
        node.getLeftExpr().accept(this);
        String right = node.getRightExpr().getExprType();
        node.getRightExpr().accept(this);

        if (TypeHelper.isPrimitive(left) && TypeHelper.isPrimitive(right)) {
            writer.println("if_icmpeq " + labels.getElse());
        }
        else {
            writer.println("if_acmpeq " + labels.getElse());
        }
        
        decrStack();
        decrStack();
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(BinaryLogicAndExpr node) {
        node.getLeftExpr().accept(this);
        node.getRightExpr().accept(this);
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(BinaryLogicOrExpr node) {
        String oldElse = labels.getElse();
        String oldThen = labels.getThen();
        String elseLbl = labels.add();

        labels.setElse(elseLbl);
        node.getLeftExpr().accept(this);
        writer.println("goto " + oldThen);
        
        writer.printlbl(elseLbl, labels);
        labels.setElse(oldElse);
        node.getRightExpr().accept(this);
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(VarExpr node) {
        String fieldOp = storeIntoVar ? "putfield " : "getfield ";

        String name = node.getName();
        if (name.equals("null")) {
            writer.println(Bytecodes.aload(-1));
            incrStack();
            return null;
        }
        else if (name.equals("this") || name.equals("super")) {
            writer.println(Bytecodes.aload(0));
            incrStack();
            return null;
        }

        if (node.getRef() instanceof VarExpr) {
            VarExpr ref = (VarExpr)node.getRef();
            ref.accept(this);

            if (ref.getName().equals("super")) {
                String parent = getClassWithField(curClass.getParent(), name);
                writer.println(fieldOp + parent + "/" +  name +
                    " " + TypeHelper.getDescriptor(node.getExprType()));

                decrStack();
                incrStack();
                return null;
            }
            else if (ref.getName().equals("this")) {
                String parent = getClassWithField(curClass.getName(), name);
                writer.println(fieldOp + parent + "/" +  name +
                    " " + TypeHelper.getDescriptor(node.getExprType()));

                decrStack();
                incrStack();
                return null;
            }
            else if (TypeHelper.isArrayBase(ref.getExprType()) &&
                name.equals("length")) {
                writer.println("arraylength");
                decrStack();
                incrStack();
                return null;
            }
        }
        else if (node.getRef() != null && name.equals("length") &&
            TypeHelper.isArrayBase(node.getRef().getExprType())) {
            writer.println("arraylength");
            decrStack();
            incrStack();
            return null;
        }

        int index = locals.getIndex(node.getName());
        
        if (index < 0) {
            writer.println(Bytecodes.aload(0));
            String parent = getClassWithField(curClass.getName(), name);
            writer.println(fieldOp + parent + "/" +  name +
                " " + TypeHelper.getDescriptor(node.getExprType()));

            incrStack();
            decrStack();
            if (!storeIntoVar) {
                incrStack();
            }
            return null;
        }
        else {
            if (TypeHelper.isPrimitive(node.getExprType())) {
                if (storeIntoVar) {
                    writer.println(Bytecodes.istore(index));
                    decrStack();
                }
                else {
                    writer.println(Bytecodes.iload(index));
                    incrStack();
                }
            }
            else {
                writer.println(Bytecodes.aload(index));
                incrStack();
            }
        }
        
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(ArrayExpr node) {
        String name = node.getName();
        String type = TypeHelper.getNonArrayType(node.getExprType());

        if (node.getRef() instanceof VarExpr) {
            VarExpr ref = (VarExpr)node.getRef();
            ref.accept(this);

            if (ref.getName().equals("super")) {
                String parent = getClassWithField(curClass.getParent(), name);
                writer.println("getfield " + parent + "/" +  name +
                    " " + TypeHelper.getDescriptor(node.getExprType() + "[]"));

                decrStack();
                incrStack();
            }
            else if (ref.getName().equals("this")) {
                String parent = getClassWithField(curClass.getName(), name);
                writer.println("getfield " + parent + "/" +  name +
                    " " + TypeHelper.getDescriptor(node.getExprType() + "[]"));

                decrStack();
                incrStack();
                return null;
            }
            else {
                int index = locals.getIndex(node.getName());
                writer.println(Bytecodes.aload(index));
                incrStack();
            }
        }
        else {
            int index = locals.getIndex(node.getName());
            
            if (index < 0) {
                writer.println(Bytecodes.aload(0));
                String parent = getClassWithField(curClass.getName(), name);
                writer.println("getfield " + parent + "/" +  name +
                    " " + TypeHelper.getDescriptor(node.getExprType() + "[]"));

                incrStack();
                decrStack();
                incrStack();
            }
            else {
                writer.println(Bytecodes.aload(index));
                incrStack();
            }
        }

        node.getIndex().accept(this);
        if (TypeHelper.isPrimitive(type)) {
            if (storeIntoVar) {
                writer.println("iastore");
                decrStack();
                decrStack();
                decrStack();
            }
            else {
                writer.println("iaload");
                decrStack();
                decrStack();
                incrStack();
            }
        }
        else {
            writer.println("aaload");
            decrStack();
            decrStack();
            incrStack();
        }

        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(ConstBooleanExpr node) {
        if (node.getConstant().equals("true")) {
            writer.println(Bytecodes.ldc(1));
        }
        else {
            writer.println(Bytecodes.ldc(0));
        }

        incrStack();
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(ConstIntExpr node) {
        writer.println(Bytecodes.ldc(Integer.valueOf(node.getConstant())));
        incrStack();
        return null;
    }
    
    /** Generate JVM opcodes for AST node
      * @param node AST node
      * @return null (returns value to satisfy compiler)
      * */
    public Object visit(ConstStringExpr node) {
        writer.println(Bytecodes.ldc(node.getConstant()));
        incrStack();
        return null;
    }
}
