package codegenjvm;

import java.io.*;
import java.util.*;
import util.ClassTreeNode;

public class JVMCodeGenerator {
    private ClassTreeNode classRoot;
    private boolean debug;

    public JVMCodeGenerator(ClassTreeNode classRoot, boolean debug) {
        this.classRoot = classRoot;
        this.debug = debug;
    }

    public void generate() throws FileNotFoundException {
        Hashtable<String, ClassTreeNode> classMap = new Hashtable<>();
        ArrayList<ClassTreeNode> toTraverse = new ArrayList<>();
        toTraverse.add(classRoot);
        
        while (toTraverse.size() > 0) {
            ArrayList<ClassTreeNode> temp = new ArrayList<>();

            for (ClassTreeNode node : toTraverse) {
                classMap.put(node.getName(), node);

                Iterator<ClassTreeNode> iter = node.getChildrenList();
                while (iter.hasNext()) {
                    temp.add(iter.next());
                }
            }

            toTraverse = temp;
        }

        CodeGenVisitor visitor = new CodeGenVisitor(classMap);

        for (String className : classMap.keySet()) {
            ClassTreeNode node = classMap.get(className);
            if (node.isBuiltIn()) {
                continue;
            }

            File outFile = new File(className + ".j");
            PrintStream outStream = new PrintStream(outFile);
            
            visitor.setOutStream(outStream);
            node.getASTNode().accept(visitor);
            outStream.close();
        }
    }
}
