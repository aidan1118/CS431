package codegenjvm;

import java.util.Hashtable;

public class TypeHelper {
    private static Hashtable<String, String> knownBases = new Hashtable<>();
    private static Hashtable<String, String> knownDescriptors = new Hashtable<>();

    static {
        knownBases.put("TextIO", "TextIO");
        knownBases.put("Object", "java/lang/Object");
        knownBases.put("String", "java/lang/String");
        knownBases.put("Sys", "Sys");

        knownDescriptors.put("int", "I");
        knownDescriptors.put("boolean", "Z");
        knownDescriptors.put("void", "V");
        knownDescriptors.put("TextIO", "LTextIO;");
        knownDescriptors.put("Object", "Ljava/lang/Object;");
        knownDescriptors.put("String", "Ljava/lang/String;");
        knownDescriptors.put("Sys", "LSys;");
    }

    public static String getBase(String type) {
        if (knownBases.containsKey(type)) {
            return knownBases.get(type);
        }

        knownBases.put(type, type);
        return type;
    }

    public static String getDescriptor(String type) {
        if (knownDescriptors.containsKey(type)) {
            return knownDescriptors.get(type);
        }

        String arrPrefix = "";
        String finalType = type;

        while (finalType.endsWith("[]")) {
            finalType = finalType.substring(0, finalType.length() - 2);
            arrPrefix += "[";
        }

        if (knownDescriptors.containsKey(finalType)) {
            finalType = knownDescriptors.get(finalType);
        }
        else {
            String key = finalType;
            finalType = "L" + finalType + ";";
            knownDescriptors.put(key, finalType);
        }
        finalType = arrPrefix + finalType;
        
        knownDescriptors.put(type, finalType);
        return finalType;
    }

    public static boolean isInt(String type) {
        return knownDescriptors.containsKey(type) &&
            knownDescriptors.get(type).equals("I");
    }

    public static boolean isBoolean(String type) {
        return knownDescriptors.containsKey(type) &&
            knownDescriptors.get(type).equals("Z");
    }

    public static boolean isPrimitive(String type) {
        return isInt(type) || isBoolean(type);
    }

    public static boolean isVoid(String type) {
        return knownDescriptors.containsKey(type) &&
            knownDescriptors.get(type).equals("V");
    }

    public static boolean isArrayBase(String type) {
        return type.endsWith("[]");
    }

    public static boolean isArrayDescriptor(String type) {
        return type.startsWith("[");
    }

    public static String getNonArrayType(String type) {
        while (type.endsWith("[]")) {
            type = type.substring(0, type.length() - 2);
        }

        return type;
    }
}
