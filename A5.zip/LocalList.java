package codegenjvm;

import java.util.*;

public class LocalList {
    private ArrayList<String> locals = new ArrayList<>();
    private ArrayList<String> types = new ArrayList<>();

    private Stack<Integer> stack = new Stack<>();
    private int maxSize = 0;

    public int getIndex(String local) {
        if (local == null) {
            return -1;
        }

        return locals.lastIndexOf(local);
    }

    public String getType(String local) {
        return types.get(locals.indexOf(local));
    }

    public void declare(String local, String type) {
        locals.add(local);
        types.add(type);

        maxSize = Math.max(maxSize, locals.size());
    }

    public void enterScope() {
        stack.push(locals.size());
    }

    public void exitScope() {
        int index = stack.pop();
        if (index >= 0) {
            locals = new ArrayList<String>(locals.subList(0, index));
            types = new ArrayList<String>(locals.subList(0, index));
        }
    }

    public void clear() {
        locals.clear();
        types.clear();

        maxSize = 0;
    }

    public int size() {
        return maxSize;
    }

    public void reset(String local, String type) {
        clear();
        declare(local, type);
    }
}
