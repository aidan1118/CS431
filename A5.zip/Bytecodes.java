package codegenjvm;

public class Bytecodes {
    private static String[] ldcLookup = new String[] {
        "iconst_m1",
        "iconst_0",
        "iconst_1",
        "iconst_2",
        "iconst_3",
        "iconst_4",
        "iconst_5"
    };
    
    public static String ldc(int value) {
        if (value >= -1 && value + 1 < ldcLookup.length) {
            return ldcLookup[value + 1];
        }

        return "ldc " + value;
    }

    public static String ldc(String value) {
        value = value.replace("\n", "\\n");
        value = value.replace("\"", "\\\"");

        return "ldc \"" + value + "\"";
    }

    private static String[] iloadLookup = new String[] {
        "iload_0",
        "iload_1",
        "iload_2",
        "iload_3"
    };

    public static String iload(int value) {
        if (value >= 0 && value < iloadLookup.length) {
            return iloadLookup[value];
        }

        return "iload " + value;
    }

    private static String[] istoreLookup = new String[] {
        "istore_0",
        "istore_1",
        "istore_2",
        "istore_3"
    };

    public static String istore(int value) {
        if (value >= 0 && value < istoreLookup.length) {
            return istoreLookup[value];
        }

        return "istore " + value;
    }

    private static String[] aloadLookup = new String[] {
        "aconst_null",
        "aload_0",
        "aload_1",
        "aload_2",
        "aload_3"
    };

    public static String aload(int value) {
        if (value >= -1 && value + 1 < aloadLookup.length) {
            return aloadLookup[value + 1];
        }

        return "aload " + value;
    }

    private static String[] astoreLookup = new String[] {
        "astore_0",
        "astore_1",
        "astore_2",
        "astore_3"
    };

    public static String astore(int value) {
        if (value >= 0 && value < astoreLookup.length) {
            return astoreLookup[value];
        }

        return "astore " + value;
    }
}
