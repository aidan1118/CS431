package codegenjvm;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Stack;

public class OutputStringWriter {
    private Stack<ByteArrayOutputStream> outStreams;
    private Stack<PrintStream> printStreams;

    private int indent = -1;
    private String space = " ";

    public OutputStringWriter() {
        outStreams = new Stack<>();
        printStreams = new Stack<>();

        enterScope();
    }

    public void incrIndent() {
        indent++;
    }

    public void incrIndent(int indent) {
        this.indent += indent;
    }

    public void decrIndent() {
        indent = Math.max(this.indent - 1, 0);
    }

    public void decrIndent(int indent) {
        this.indent = Math.max(this.indent - indent, 0);
    }

    public int getIndent() {
        return indent;
    }

    public void setIndent(int indent) {
        this.indent = Math.max(indent, 0);
    }

    public void enterScope() {
        incrIndent();
        outStreams.push(new ByteArrayOutputStream());
        printStreams.push(new PrintStream(outStreams.peek()));
    }

    public void exitScope() {
        decrIndent();
        outStreams.pop();
        printStreams.pop();
    }

    public void print(String str) {
        printStreams.peek().print(str);
    }

    public void println(String str) {
        String tab = space.repeat(indent * 4);
        printStreams.peek().println(tab + str);
    }

    public void printlbl(String lbl, LabelList labels) {
        String tab = space.repeat((indent - 1) * 4);
        printStreams.peek().println(tab + lbl + ":");
        labels.addOrdered(lbl);
    }

    public void println() {
        printStreams.peek().println();
    }

    public void finishln(String str) {
        printStreams.peek().println(str);
    }

    public String getString() {
        return outStreams.peek().toString();
    }

    public String getProcessed(LabelList labels) {
        String str = getString();
        return labels.processLabels(str);
    }
}
