package codegenjvm;

import java.util.ArrayList;

public class LabelList {
    private ArrayList<String> labels = new ArrayList<>();
    private ArrayList<String> labelsOrdered = new ArrayList<>();

    private String thenLbl;
    private String elseLbl;
    private String elseLoopLbl;

    public String add() {
        String label = "L%" + (labels.size() + 1);
        labels.add(label);
        return label;
    }

    public void addOrdered(String label) {
        labelsOrdered.add(label);
    }

    public void setThen(String label) {
        thenLbl = label;
    }

    public String getThen() {
        return thenLbl;
    }

    public void setElse(String label) {
        elseLbl = label;
    }

    public String getElse() {
        return elseLbl;
    }

    public void setLoopElse(String label) {
        setElse(label);
        elseLoopLbl = label;
    }

    public String getLoopElse() {
        return elseLoopLbl;
    }

    public int size() {
        return labels.size();
    }

    public void clear() {
        labels.clear();
        labelsOrdered.clear();
    }

    public String processLabel(String input, String label) {
        String sep = System.lineSeparator();

        if (labelsOrdered.contains(label)) {
            String replacement = "L" + (labelsOrdered.indexOf(label) + 1);
            input = input.replace(label + sep, replacement + sep);
            input = input.replace(label + ":", replacement + ":");
        }

        return input;
    }

    public String processLabels(String input) {
        for (String label : labels) {
            input = processLabel(input, label);
        }

        return input;
    }
}
